"""Portable CPU tests for predictor-only exact-meta pilot. Run from YOLOX root."""
from pathlib import Path
import sys
import math
import tempfile
import torch

ROOT=Path(__file__).resolve().parents[1]
TOOLS=ROOT/'tools'
# For extracted YOLOX tree, use copied tools/; otherwise allow local source package.
if not (TOOLS/'safe_ttt_model.py').exists():
    TOOLS=Path(__file__).resolve().parents[2]/'vnext2_ttt_training_attribution'/'tools'
sys.path.insert(0,str(TOOLS))
sys.path.insert(0,str(ROOT/'tools'))
from safe_ttt_model import SafeSpatialTTT
from pilot_safe_ttt_predictor_only import (
    select_predictor_only, exact_frozen_snapshot, check_frozen, predictor_delta,
    summarize_holdout, scalar_image_cosine, save_sidecar_early,
    validate_report_only_checkpoint,
)


def build():
    torch.manual_seed(20261104)
    m=SafeSpatialTTT(16,rank=4,step_policy='normalized')
    return m


def test_freeze_and_nonpredictor_immutability():
    m=build()
    chosen, frozen=select_predictor_only(m)
    before=exact_frozen_snapshot(m)
    predictor_before={n:p.detach().clone() for n,p in chosen}
    opt=torch.optim.AdamW([p for _,p in chosen],lr=0.0005,weight_decay=0)
    x=torch.randn(1,16,8,8)
    target=x.detach()+torch.randn_like(x)*0.2
    adapted,_=m.run_episode(x,meta_train=True)
    obj=(adapted-target).square().mean()
    opt.zero_grad(set_to_none=True)
    obj.backward()
    pred_grads=[p.grad for _,p in chosen]
    assert all(g is not None and torch.isfinite(g).all() for g in pred_grads)
    assert any(float(g.detach().abs().sum())>0 for g in pred_grads)
    assert all(p.grad is None for _,p in frozen)
    opt.step()
    check_frozen(m,before)
    assert predictor_delta(m,predictor_before)>0


def test_unknown_key_rejected():
    m=build()
    m.rogue=torch.nn.Parameter(torch.ones(1))
    try: select_predictor_only(m)
    except RuntimeError as err:assert 'Unknown parameter' in str(err)
    else:raise AssertionError('Unknown parameter accepted')


def test_holdout_assesses_paired_changes():
    initial=[{'index':10,'native':1.0,'delta':-0.0001,'cosine':-0.1},
             {'index':11,'native':1.0,'delta':0.0002,'cosine':0.2}]
    trained=[{'index':10,'native':1.0,'delta':-0.0002,'cosine':0.1},
             {'index':11,'native':1.0,'delta':0.0003,'cosine':0.1}]
    result=summarize_holdout(initial,trained)
    assert result['train_state_better_count']==1
    assert result['train_state_worse_count']==1
    assert result['sample_size']==2
    assert result['trained_beneficial_count']==1


def test_holdout_rejects_reordered_indices():
    base=[{'index':1,'native':1.,'delta':0.,'cosine':0.},
          {'index':2,'native':1.,'delta':0.,'cosine':0.}]
    try:summarize_holdout(base,list(reversed(base)))
    except RuntimeError as err:assert 'order' in str(err)
    else:raise AssertionError('Holdout reordering accepted')


def test_singleton_list_cosine_and_undefined_cosine():
    before=[{'index':10,'native':2.0,'delta':-1e-4,'cosine':[-0.25]},
            {'index':11,'native':1.0,'delta':0.0,'cosine':[None]}]
    after=[{'index':10,'native':2.0,'delta':-2e-4,'cosine':[0.4]},
           {'index':11,'native':1.0,'delta':1e-4,'cosine':None}]
    r=summarize_holdout(before,after)
    assert r['sample_size']==2
    assert r['mean_cosine_initial']==-0.25
    assert r['mean_cosine_trained']==0.4
    assert r['per_image'][1]['initial_cosine'] is None
    assert r['per_image'][1]['trained_cosine'] is None
    assert math.isclose(r['mean_trained_minus_initial'],0,abs_tol=1e-12)
    assert scalar_image_cosine(0.6)==0.6


def test_cosine_multi_image_shape_rejected():
    a=[{'index':1,'native':1.,'delta':0.,'cosine':[0.1,0.2]}]
    b=[{'index':1,'native':1.,'delta':0.,'cosine':[0.2]}]
    try: summarize_holdout(a,b)
    except ValueError as error: assert 'exactly one' in str(error)
    else: raise AssertionError('Unexpectedly accepted batched cosine in single-image audit')
    for x in ([float('nan')],float('inf'),[1.5]):
        try: scalar_image_cosine(x)
        except ValueError: pass
        else: raise AssertionError('Accepted invalid cosine')


def test_checkpoint_save_before_report_and_recovery():
    # Without the expensive detector, verify durable state persistence and
    # recovery when a later reporting error raises an exception.
    m=build()
    config={k:0 for k in ('native_sha256','weights','model_exp','seed',
        'train_indices','holdout_indices','steps','lr','rank','basis_gain',
        'step_policy','min_signal_norm','objective_mode','nonregression_weight')}
    config['steps']=1
    config['train_indices']=[300]
    config['holdout_indices']=[500]
    with tempfile.TemporaryDirectory() as directory:
        from pathlib import Path
        path=Path(directory)/'sidecar.pth'
        before=[{'index':500,'native':1.,'delta':0.,'cosine':[0.2]}]
        save_sidecar_early(path,m.state_dict(),config,[{'step':1}],before,0.01)
        assert path.exists()
        try:
            summarize_holdout([{'index':500,'native':1.,'delta':0.,'cosine':[0.2,0.3]}],before)
        except ValueError:
            pass
        else: raise AssertionError('Expected a failure in post-training report')
        # The checkpoint already exists despite the simulated report failure.
        saved=torch.load(path,map_location='cpu',weights_only=False)
        validate_report_only_checkpoint(saved,config)
        m2=build()
        m2.load_state_dict(saved['safe_ttt'],strict=True)
        assert all(torch.equal(v,m2.state_dict()[k]) for k,v in m.state_dict().items())
        assert saved['before_holdout']==before
        try: save_sidecar_early(path,m.state_dict(),config,[],before,0.01)
        except FileExistsError: pass
        else: raise AssertionError('Overwrote existing checkpoint')
        bad=dict(config,seed=42)
        try: validate_report_only_checkpoint(saved,bad)
        except ValueError as error: assert 'seed' in str(error)
        else: raise AssertionError('Accepted mismatched seed')


if __name__=='__main__':
    torch.set_num_threads(1)
    for name,func in list(globals().items()):
        if name.startswith('test_') and callable(func):
            func()
            print('PASS',name)

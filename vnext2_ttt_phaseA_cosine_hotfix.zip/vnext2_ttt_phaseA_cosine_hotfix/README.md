# vNext.2 Phase A predictor-only: holdout cosine + early checkpoint hotfix

## What happened

All 16 meta-training iterations succeeded. The original `evaluate_source_holdout()` returns a per-image gradient cosine as a **list** (for batch 1, `[cos]`, or `[None]` when a gradient norm is zero). The predictor-only pilot then calls `float(a['cosine'])`, which raises `TypeError` for a list. Its prior CPU tests incorrectly supplied a scalar. The pilot also wrote the sidecar checkpoint **after** reporting; hence the crash discarded the in-memory trained sidecar.

This hotfix does **not** modify training, optimizer, model architecture, seeds, mixed derivatives, task loss, or evaluation metrics. It changes only the report-format adapter and save/recovery workflow.

## Changes

- `scalar_image_cosine(...)` accepts scalar `float`, singleton `[float]`, `None` or `[None]`. It fails closed for non-singleton cosine lists and out-of-range/nonfinite values.
- Summary means ignore undefined cosines and return JSON `null` if none is defined, rather than silently inventing zero.
- On a successful training loop, `--save-sidecar` is written **before** the post-training holdout and JSON reporting, by writing a temporary file and atomically replacing it. The script refuses to overwrite an existing checkpoint.
- Sidecar files now contain protocol metadata, a full trace of completed steps, initial holdout measurements and predictor displacement.
- New `--evaluate-only-sidecar FILE` mode reloads that saved sidecar and regenerates the holdout report **without training**. It validates configuration, native model hash, and state dictionary strictly. It is designed for a *future* reporting error after `SAVED_SIDECAR_EARLY` appears.

## Install — original repository root is `D:\YOLOX-3rd`

Extract this zip preserving folders, then copy:

```powershell
Copy-Item .\vnext2_ttt_phaseA_cosine_hotfix\tools\pilot_safe_ttt_predictor_only.py .\tools\ -Force
Copy-Item .\vnext2_ttt_phaseA_cosine_hotfix\tests\test_safe_ttt_predictor_only.py .\tests\ -Force
python tests/test_safe_ttt_predictor_only.py
```

Expected 7 PASS lines (including a singleton-list cosine test and a checkpoint-before-report-failure test).

## Rerun the original 16-step pilot once

The first process exited before it saved weights. No sidecar checkpoint could be recovered from the console log. **This one rerun is unavoidable unless another tool in your environment independently saved those exact weights.** You do not need to retrain YOLOX or run a full epoch.

```powershell
python tools/pilot_safe_ttt_predictor_only.py `
  --checkpoint YOLOX_outputs/tde_yolox_s_full_vnext2/latest_ckpt.pth `
  --model-exp exps/default/tde_yolox_s.py `
  --weights ema `
  --train-indices 300 301 302 303 304 305 306 307 308 309 310 311 312 313 314 315 `
  --holdout-indices 500 501 502 503 504 505 506 507 `
  --steps 16 --lr 0.0001 `
  --seed 20261104 `
  --objective-mode detector_total `
  --step-policy normalized --rank 8 --basis-gain 1 `
  --output audits/safe_ttt_predictor_only_phaseA.json `
  --save-sidecar audits/safe_ttt_predictor_only_phaseA.pth
```

Successful execution prints `SAVED_SIDECAR_EARLY ...` immediately after the final step, **before** evaluating the trained holdout. Later it prints paired held-out effects and writes JSON.

## If report evaluation ever fails again after the early checkpoint save

Re-run reporting only (no optimizer step):

```powershell
python tools/pilot_safe_ttt_predictor_only.py `
  --checkpoint YOLOX_outputs/tde_yolox_s_full_vnext2/latest_ckpt.pth `
  --model-exp exps/default/tde_yolox_s.py `
  --weights ema `
  --train-indices 300 301 302 303 304 305 306 307 308 309 310 311 312 313 314 315 `
  --holdout-indices 500 501 502 503 504 505 506 507 `
  --steps 16 --lr 0.0001 `
  --seed 20261104 `
  --objective-mode detector_total `
  --step-policy normalized --rank 8 --basis-gain 1 `
  --output audits/safe_ttt_predictor_only_phaseA_recovered.json `
  --evaluate-only-sidecar audits/safe_ttt_predictor_only_phaseA.pth
```

If the first run succeeded and wrote a report, don't run recovery. If its report already exists, use a distinct `--output` filename (the script refuses overwrite). Use `--evaluate-only-sidecar` **without** `--save-sidecar`. The saved checkpoint must come from this hotfix or a later implementation with the same checkpoint metadata.

## What to report back

Share the lines beginning `HELDOUT`, `PREDICTOR_L2_CHANGE`, and `SAVED`; preferably share the complete `heldout` JSON section. The pilot is a source-clean fixed-SimOTA diagnostic, not a guarantee of clean validation or adverse-domain AP/AR.

## Validation

Seven CPU tests passed locally, including original frozen-state/gradient tests and regression cases for singleton/undefined cosine, malformed multi-item cosine, early atomic save and reload, overwrite refusal, and configuration mismatch. `python -m py_compile` passed. The full trained checkpoint/CUDA experiment is not available in this container.
